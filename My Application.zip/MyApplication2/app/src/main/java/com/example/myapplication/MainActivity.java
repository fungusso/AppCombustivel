package com.example.myapplication;

import java.text.DecimalFormat;
import java.text.NumberFormat;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.ekn.gruzer.gaugelibrary.HalfGauge;
import com.ekn.gruzer.gaugelibrary.Range;
import android.content.Intent;
import androidx.activity.result.contract.ActivityResultContracts;


public class MainActivity extends AppCompatActivity {
    private Button btCalcular;
    private Button btlimpar;

    private Button btTiproad;
    private EditText etPeso;
    private EditText etAltura;

    private HalfGauge halfGauge;
    private TextView tvRsultadoEscrito;

    private TextView RResultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btCalcular = findViewById(R.id.btCalcular);
        btlimpar = findViewById(R.id.btLimpar);
        etAltura = findViewById(R.id.etAltura);
        etPeso = findViewById(R.id.etPeso);
        btTiproad = findViewById(R.id.btTiproad);

        halfGauge = findViewById(R.id.halfGauge);
        tvRsultadoEscrito = findViewById(R.id.tvResultadoEscrito);
        RResultado = findViewById(R.id.RResultado);
        Range range1 = new Range();
        Range range2 = new Range();
        Range range3 = new Range();
        Range range4 = new Range();
        Range range5 = new Range();
        Range range6 = new Range();
        Range range7 = new Range();
        Range range8 = new Range();
        Range range9 = new Range();
        Range range10 = new Range();



        range1.setColor(Color.parseColor( "#006400"));
        range1.setFrom(1.0);
        range1.setTo(10.0);

        range2.setColor(Color.parseColor( "#2E8B57"));
        range2.setFrom(10.1);
        range2.setTo(20.0);

        range3.setColor(Color.parseColor( "#008000"));
        range3.setFrom(20.1);
        range3.setTo(30.0);

        range4.setColor(Color.parseColor( "#32CD32"));
        range4.setFrom(30.1);
        range4.setTo(40.0);

        range5.setColor(Color.parseColor( "#3CB371"));
        range5.setFrom(40.1);
        range5.setTo(50.0);

        range6.setColor(Color.parseColor( "#90EE90"));
        range6.setFrom(50.1);
        range6.setTo(60.0);

        range7.setColor(Color.parseColor( "#98FB98"));
        range7.setFrom(60.1);
        range7.setTo(69.1);

        range8.setColor(Color.parseColor( "#FFA07A"));
        range8.setFrom(70.0);
        range8.setTo(80.0);

        range9.setColor(Color.parseColor( "#FF6347"));
        range9.setFrom(80.1);
        range9.setTo(90.0);

        range10.setColor(Color.parseColor( "#FF0000"));
        range10.setFrom(90.1);
        range10.setTo(100.0);

        halfGauge.addRange(range1);
        halfGauge.addRange(range2);
        halfGauge.addRange(range3);
        halfGauge.addRange(range4);
        halfGauge.addRange(range5);
        halfGauge.addRange(range6);
        halfGauge.addRange(range7);
        halfGauge.addRange(range8);
        halfGauge.addRange(range9);
        halfGauge.addRange(range10);

        halfGauge.setValueColor(Color.BLACK);
        halfGauge.setMaxValueTextColor(Color.RED);
        halfGauge.setMinValueTextColor(Color.BLUE);
        halfGauge.setMaxValue(100);
        halfGauge.setMinValue(1);

        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btCalcularOnClick();
                }
            });
        btlimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                halfGauge.setValue(0.00);
                 etAltura.setText("");
                 etPeso.setText("");
                 RResultado.setText("");
                 tvRsultadoEscrito.setText("");
                 etPeso.requestFocus();
            }
        });



    }

    private void btCalcularOnClick() {
        if (etPeso.getText().toString().isEmpty()){
            etPeso.setError("Campo Peso deve ser preenchido");
            etPeso.requestFocus();
            return;
        }
        if (etAltura.getText().toString().isEmpty()){
            etAltura.setError("Campo Altura deve ser preenchido");
            etAltura.requestFocus();
            return;
        }

        NumberFormat  f = NumberFormat.getCurrencyInstance();
        DecimalFormat ff = new DecimalFormat("0.00");
        DecimalFormat fofa = new DecimalFormat( "0,00");

        System.out.println("peso " + etPeso);
        System.out.println("altura " + etAltura);
        double peso = Double.parseDouble(etPeso.getText().toString());
        double altura = Double.parseDouble(etAltura.getText().toString());

        double resultado = (peso / altura) * 100;


         System.out.println("resultado======> " + resultado);
       //  System.out.println(str);
          //halfGauge.setValue(resultado);
        halfGauge.setValue(Double.parseDouble(ff.format(resultado)));
       // halfGauge.setValue(Double.parseDouble(ff.format(resultado1)));

        if (resultado < 10){
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#006400"));
            tvRsultadoEscrito.setText("Álcool");

        } else if (resultado >= 10.1 && resultado < 20) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#2E8B57"));
            tvRsultadoEscrito.setText("Álcool");

        } else if (resultado >= 20.1 && resultado < 30 ) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#008000"));
            tvRsultadoEscrito.setText("Álcool");

        } else if (resultado >= 30.1 && resultado < 40) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#32CD32"));
            tvRsultadoEscrito.setText("Álcool");

        } else if (resultado >= 40.1 && resultado < 50) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#90EE90"));
            tvRsultadoEscrito.setText("Álcoll");

        } else if (resultado >= 50.1 && resultado < 60) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#FA8072"));
            tvRsultadoEscrito.setText("Álcool");

        } else if (resultado >= 60.1 && resultado < 70) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#E9967A"));
            tvRsultadoEscrito.setText("Álcool");
        }else if (resultado >= 70.1) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#FF0000"));
            tvRsultadoEscrito.setText("Gasolina");
        }
    }

}


