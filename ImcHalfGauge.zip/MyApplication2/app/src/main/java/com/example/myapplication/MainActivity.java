package com.example.myapplication;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.ekn.gruzer.gaugelibrary.HalfGauge;
import com.ekn.gruzer.gaugelibrary.Range;


public class MainActivity extends AppCompatActivity {
    private Button btCalcular;
    private Button btlimpar;

    private EditText etPeso;
    private EditText etAltura;

    private HalfGauge halfGauge;
    private TextView tvRsultadoEscrito;

    private TextView RResultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btCalcular = findViewById(R.id.btCalcular);
        btlimpar = findViewById(R.id.btLimpar);
        etAltura = findViewById(R.id.etAltura);
        etPeso = findViewById(R.id.etPeso);

        halfGauge = findViewById(R.id.halfGauge);
        tvRsultadoEscrito = findViewById(R.id.tvResultadoEscrito);
        RResultado = findViewById(R.id.RResultado);
        Range range1 = new Range();
        Range range2 = new Range();
        Range range3 = new Range();
        Range range4 = new Range();
        Range range5 = new Range();

        range5.setColor(Color.parseColor( "#ea2340"));
        range5.setFrom(40);
        range5.setTo(46.0);

        range4.setColor(Color.parseColor( "#fb7a38"));
        range4.setFrom(30);
        range4.setTo(39.9);

        range3.setColor(Color.parseColor( "#f3e141"));
        range3.setFrom(25);
        range3.setTo(29.9);

        range2.setColor(Color.parseColor( "#5ebf4b"));
        range2.setFrom(18.6);
        range2.setTo(24.9);

        range1.setColor(Color.parseColor( "#4edafe"));
        range1.setFrom(0);
        range1.setTo(18.5);

        halfGauge.addRange(range1);
        halfGauge.addRange(range2);
        halfGauge.addRange(range3);
        halfGauge.addRange(range4);
        halfGauge.addRange(range5);

        halfGauge.setValueColor(Color.BLACK);
        halfGauge.setMaxValueTextColor(Color.RED);
        halfGauge.setMinValueTextColor(Color.BLUE);
        halfGauge.setMaxValue(46);
        halfGauge.setMinValue(13.5);

        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                btCalcularOnClick();
                }
            });
        btlimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                 etAltura.setText("");
                 etPeso.setText("");
                 RResultado.setText("");
                 tvRsultadoEscrito.setText("");
                 etPeso.requestFocus();
            }
        });




    }
    private void btCalcularOnClick() {
        if (etPeso.getText().toString().isEmpty()){
            etPeso.setError("Campo Peso deve ser preenchido");
            etPeso.requestFocus();
            return;
        }
        if (etAltura.getText().toString().isEmpty()){
            etAltura.setError("Campo Altura deve ser preenchido");
            etAltura.requestFocus();
            return;
        }
        NumberFormat  f = NumberFormat.getCurrencyInstance();
        DecimalFormat ff = new DecimalFormat("0.00");
        DecimalFormat fofa = new DecimalFormat( "0,00");

        System.out.println("peso " + etPeso);
        System.out.println("altura " + etAltura);
        double peso = Double.parseDouble(etPeso.getText().toString());
        double altura = Double.parseDouble(etAltura.getText().toString());

        double resultado = peso / Math.pow(altura, 2);
         System.out.println("resultado======> " + resultado);
       //  System.out.println(str);
          halfGauge.setValue(resultado);

        if (resultado < 18.5){
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#4edafe"));
            tvRsultadoEscrito.setText("MAGRESA");

        } else if (resultado >= 18.5 && resultado < 25) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#5ebf4b"));
            tvRsultadoEscrito.setText("BELEZA");

        } else if (resultado >= 25 && resultado < 30 ) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#f3e141"));
            tvRsultadoEscrito.setText("ACIMA DO PESO");
        } else if (resultado >= 30 && resultado < 40) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#fb7a38"));
            tvRsultadoEscrito.setText("OBESIDADE");
        } else if (resultado >= 40) {
            tvRsultadoEscrito.setTextColor(Color.parseColor( "#ea2340"));
            tvRsultadoEscrito.setText("SEVERA OBESIDADE");
        }
    }

}


